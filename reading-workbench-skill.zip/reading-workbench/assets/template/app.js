/* ============================================================
   阅读 C 篇 · 双栏互动阅读教学工作台
   结构：原文以「带全局精确偏移量的文本节点」渲染，
   - 荧光笔/下划线/文字批注 → 锚定到文本偏移（重排、缩放、滚动均不错位）
   - 画笔/画圈/箭头 → SVG 覆盖层，坐标以「原文内容区」为参照单位
   ============================================================ */
(function () {
  'use strict';

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const clone = (o) => JSON.parse(JSON.stringify(o));

  /* ================= 状态 ================= */
  const S = {
    // 批注
    marks: [],           // {id,type:'hl'|'ul',para,start,end,color}
    annos: [],           // {id,type:'text',para,pos,text,color}
    ink: [],             // {id,para,type,color,d:[{x,y}] | box | text}
    undo: [], redo: [],
    // 工具
    tool: 'select',
    color: 'yellow',
    // 题目
    current: 'q28',
    revealed: { q28: {}, q29: {}, q30: {}, q31: {} },
    // 证据（系统层，独立于教师批注）
    evidenceOn: false,
    // 词汇
    match: { selEn: null, selZh: null, done: {}, wrong: {}, count: 0 },
    // 句子分析
    sentences: [],
    fontSize: 18,
    // 临时
    lastPara: 1
  };

  const COLORS = { yellow: '#E6B800', blue: '#2563EB', green: '#12B886', coral: '#FF6B4A' };

  /* ================= 原文渲染 ================= */
  const passageEl = $('#passage');
  let paraNodes = [];      // [{el, txt, start}]  start: 全局偏移起点
  let globalText = '';     // 纯文本（不含编号），用于选区偏移映射

  function buildPassage() {
    passageEl.innerHTML = '';
    paraNodes = [];
    globalText = '';
    window.PASSAGE.paragraphs.forEach((text, i) => {
      const p = document.createElement('div');
      p.className = 'para';
      p.dataset.para = i + 1;
      const no = document.createElement('span');
      no.className = 'paraNo';
      no.textContent = '¶' + (i + 1);
      const txtWrap = document.createElement('div');
      txtWrap.style.position = 'relative';
      txtWrap.style.zIndex = '2';

      const tn = document.createElement('span');
      tn.className = 'en';
      tn.appendChild(document.createTextNode(text));
      txtWrap.appendChild(tn);

      // 文本批注层（绝对定位，随段落移动）
      const al = document.createElement('div');
      al.className = 'annoTextLayer';
      al.dataset.annoLayer = i + 1;
      txtWrap.appendChild(al);

      // 墨迹层
      const il = document.createElement('div');
      il.className = 'inkLayer';
      il.dataset.inkLayer = i + 1;
      const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      svg.setAttribute('preserveAspectRatio', 'none');
      il.appendChild(svg);
      txtWrap.appendChild(il);

      p.appendChild(no);
      p.appendChild(txtWrap);
      passageEl.appendChild(p);

      paraNodes.push({ el: p, txt: tn, start: globalText.length, text });
      globalText += text + '\n';
    });
    applyInkMode();
  }

  /* --- 全局选区 → 段落 + 偏移 --- */
  function offsetInPara(paraIdx, node, offset) {
    const para = paraNodes[paraIdx];
    const walker = document.createTreeWalker(para.txt, NodeFilter.SHOW_TEXT);
    let n, total = 0;
    while ((n = walker.nextNode())) {
      if (n === node) return total + offset;
      total += n.nodeValue.length;
    }
    return null;
  }

  function paraIndexOfNode(node) {
    const p = node.nodeType === 1 ? node.closest('.para') : node.parentElement?.closest('.para');
    return p ? parseInt(p.dataset.para, 10) - 1 : -1;
  }

  function getSelectionInfo() {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0 || sel.isCollapsed) return null;
    const range = sel.getRangeAt(0);
    if (!passageEl.contains(range.commonAncestorContainer)) return null;

    const pi = paraIndexOfNode(range.startContainer);
    const pj = paraIndexOfNode(range.endContainer);
    if (pi < 0 || pj < 0) return null;

    const s = offsetInPara(pi, range.startContainer, range.startOffset);
    const e = offsetInPara(pj, range.endContainer, range.endOffset);
    if (s == null || e == null) return null;

    const text = sel.toString().replace(/\s+/g, ' ').trim();
    if (!text) return null;

    if (pi === pj) {
      const [a, b] = s <= e ? [s, e] : [e, s];
      return { single: true, para: pi + 1, start: a, end: b, text, rect: range.getBoundingClientRect() };
    }
    return {
      single: false, para: pi + 1, start: s, end: e, text,
      para2: pj + 1, start2: s, end2: e,
      rect: range.getBoundingClientRect()
    };
  }

  /* --- 按偏移包裹文本（同一段落内） --- */
  function wrapRange(paraIdx, start, end, wrapperFn) {
    const para = paraNodes[paraIdx];
    if (!para) return [];
    const walker = document.createTreeWalker(para.txt, NodeFilter.SHOW_TEXT);
    const segs = [];
    let n, pos = 0;
    while ((n = walker.nextNode())) {
      const len = n.nodeValue.length;
      const a = Math.max(pos, start), b = Math.min(pos + len, end);
      if (a < b) segs.push({ node: n, from: a - pos, to: b - pos });
      pos += len;
    }
    const created = [];
    segs.forEach(seg => {
      const t = seg.node;
      if (seg.to < t.nodeValue.length) t.splitText(seg.to);
      if (seg.from > 0) {
        const mid = t.splitText(seg.from);
        const w = wrapperFn();
        mid.parentNode.insertBefore(w, mid);
        w.appendChild(mid);
        created.push(w);
      } else {
        const w = wrapperFn();
        t.parentNode.insertBefore(w, t);
        w.appendChild(t);
        created.push(w);
      }
    });
    return created;
  }

  function normalizePara(paraIdx) {
    const para = paraNodes[paraIdx];
    if (!para) return;
    para.txt.normalize();
  }

  /* --- 重绘所有教师标记（文本层） --- */
  function renderMarks() {
    paraNodes.forEach((p, i) => {
      // 清除旧的 mark/span.ul（保留纯文本）
      $$('mark.hl, span.ul', p.txt).forEach(el => {
        const parent = el.parentNode;
        while (el.firstChild) parent.insertBefore(el.firstChild, el);
        parent.removeChild(el);
      });
      p.txt.normalize();
    });

    // 下划线先画，高亮后画（生成 mark 包裹 ul 的嵌套结构）
    const ordered = [...S.marks.filter(m => m.type === 'ul'), ...S.marks.filter(m => m.type === 'hl')];
    ordered.forEach(m => {
      const idx = m.para - 1;
      wrapRange(idx, m.start, m.end, () => {
        const el = document.createElement(m.type === 'hl' ? 'mark' : 'span');
        el.className = (m.type === 'hl' ? 'hl hl-' : 'ul ul-') + m.color;
        el.dataset.markId = m.id;
        return el;
      });
    });

    renderAnnos();
    renderEvidence();
  }

  /* --- 文字批注 --- */
  function renderAnnos() {
    $$('.annoTextLayer', passageEl).forEach(l => l.innerHTML = '');
    S.annos.forEach(a => {
      const para = paraNodes[a.para - 1];
      if (!para) return;
      const pos = charPos(para.txt, a.pos);
      if (!pos) return;
      const badge = document.createElement('span');
      badge.className = 'textAnno c-' + a.color;
      badge.dataset.annoId = a.id;
      badge.textContent = a.text;
      badge.title = '点击删除此批注';
      const r = document.createRange();
      r.setStart(pos.node, pos.offset);
      r.collapse(true);
      const rect = r.getBoundingClientRect();
      const baseRect = para.txt.getBoundingClientRect();
      badge.style.position = 'absolute';
      badge.style.left = (rect.left - baseRect.left) + 'px';
      badge.style.top = (rect.top - baseRect.top - 6) + 'px';
      badge.style.zIndex = '5';
      badge.style.pointerEvents = 'auto';
      const layer = $(`.annoTextLayer[data-anno-layer="${a.para}"]`, passageEl);
      layer.appendChild(badge);
    });
  }

  function charPos(root, offset) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let n, total = 0;
    while ((n = walker.nextNode())) {
      if (offset <= total + n.nodeValue.length) return { node: n, offset: Math.max(0, offset - total) };
      total += n.nodeValue.length;
    }
    return null;
  }

  /* --- 证据高亮（系统层） --- */
  function renderEvidence() {
    // 清掉旧证据
    $$('mark.ev', passageEl).forEach(el => {
      const parent = el.parentNode;
      while (el.firstChild) parent.insertBefore(el.firstChild, el);
      parent.removeChild(el);
    });
    paraNodes.forEach(p => p.txt.normalize());

    if (!S.evidenceOn) return;
    const st = S.revealed[S.current] || {};
    if (S.current === 'summary') return;
    const q = window.QUESTIONS.find(x => x.id === S.current);
    if (!q) return;
    q.evidence.forEach((ev, i) => {
      const idx = ev.para - 1;
      const pos = paraNodes[idx].text.indexOf(ev.text);
      const scoped = ev.text.split('...')[0];
      let s = pos, e;
      if (pos >= 0) { e = pos + ev.text.length; }
      else {
        const p2 = paraNodes[idx].text.indexOf(scoped);
        if (p2 < 0) return;
        s = p2; e = p2 + scoped.length;
      }
      wrapRange(idx, s, e, () => {
        const m = document.createElement('mark');
        m.className = 'ev' + (i > 0 ? ' ev2' : '');
        m.dataset.ev = ev.tag;
        return m;
      });
    });
  }

  /* ================= 墨迹层 ================= */
  function inkLayerOf(para) { return $(`.inkLayer[data-ink-layer="${para}"]`, passageEl); }

  function applyInkMode() {
    // 说明：内联样式优先，避免依赖 CSS 类是否生效（首次渲染时类名可能尚未被重算）
    const draw = (S.tool === 'pen' || S.tool === 'circle' || S.tool === 'arrow');
    const erase = (S.tool === 'eraser');
    $$('.inkLayer', passageEl).forEach(l => {
      l.classList.toggle('drawMode', draw);
      l.classList.toggle('eraseMode', erase);
      l.style.pointerEvents = (draw || erase) ? 'auto' : 'none';
      l.style.cursor = draw ? 'crosshair' : (erase ? 'cell' : 'auto');
      // 绘制层压住正文，删除层也需要能接住点击
      l.style.zIndex = (draw || erase) ? '6' : '3';
    });
    // 画笔/橡皮启用时，禁止正文进入原生选择，避免拖动变成选字
    const en = $$('.passage .en', passageEl);
    en.forEach(e => { e.style.userSelect = (draw || erase) ? 'none' : ''; });
  }

  function renderInk() {
    paraNodes.forEach((p, i) => {
      const layer = inkLayerOf(i + 1);
      const svg = layer.querySelector('svg');
      const w = layer.clientWidth, h = layer.clientHeight;
      svg.setAttribute('viewBox', `0 0 ${w} ${h}`);
      svg.setAttribute('width', w);
      svg.setAttribute('height', h);
      svg.innerHTML = '';
      S.ink.filter(k => k.para === i + 1).forEach(k => {
        svg.appendChild(inkEl(k, w, h));
      });
    });
  }

  function inkEl(k, w, h) {
    const NS = 'http://www.w3.org/2000/svg';
    let el;
    if (k.type === 'pen') {
      el = document.createElementNS(NS, 'path');
      el.setAttribute('d', k.d.map((pt, i) => (i ? 'L' : 'M') + (pt.x * w).toFixed(1) + ' ' + (pt.y * h).toFixed(1)).join(' '));
      el.setAttribute('stroke', COLORS[k.color]);
      el.setAttribute('stroke-width', k.w || 3);
      el.setAttribute('class', 'inkPath');
    } else if (k.type === 'arrow') {
      const p0 = k.d[0], p1 = k.d[k.d.length - 1];
      const x0 = p0.x * w, y0 = p0.y * h, x1 = p1.x * w, y1 = p1.y * h;
      const ang = Math.atan2(y1 - y0, x1 - x0), L = 13;
      const bx = x1 - Math.cos(ang) * 8, by = y1 - Math.sin(ang) * 8;
      el = document.createElementNS(NS, 'g');
      const line = document.createElementNS(NS, 'path');
      line.setAttribute('d', `M${x0} ${y0} L${bx} ${by}`);
      line.setAttribute('stroke', COLORS[k.color]);
      line.setAttribute('stroke-width', k.w || 3);
      line.setAttribute('class', 'inkPath');
      const head = document.createElementNS(NS, 'path');
      head.setAttribute('d', `M${x1} ${y1} L${x1 - Math.cos(ang - 0.42) * L} ${y1 - Math.sin(ang - 0.42) * L} M${x1} ${y1} L${x1 - Math.cos(ang + 0.42) * L} ${y1 - Math.sin(ang + 0.42) * L}`);
      head.setAttribute('stroke', COLORS[k.color]);
      head.setAttribute('stroke-width', k.w || 3);
      head.setAttribute('class', 'inkPath');
      el.appendChild(line); el.appendChild(head);
    } else if (k.type === 'circle') {
      if (k.d && k.d.length > 2) {
        // 手绘圈：沿轨迹的闭合曲线（平滑），更贴合课堂“圈住”动作
        el = document.createElementNS(NS, 'path');
        el.setAttribute('d', smoothLoop(k.d, w, h));
        el.setAttribute('fill', k.fill ? COLORS[k.color] : 'none');
        el.setAttribute('fill-opacity', k.fill ? 0.12 : 0);
        el.setAttribute('stroke', COLORS[k.color]);
        el.setAttribute('stroke-width', k.w || 2.6);
        el.setAttribute('class', 'inkPath');
      } else {
        const b = k.box;
        el = document.createElementNS(NS, 'ellipse');
        el.setAttribute('cx', ((b.x + b.w / 2) * w).toFixed(1));
        el.setAttribute('cy', ((b.y + b.h / 2) * h).toFixed(1));
        el.setAttribute('rx', (Math.max(Math.abs(b.w) / 2, 4) * w).toFixed(1));
        el.setAttribute('ry', (Math.max(Math.abs(b.h) / 2, 4) * h).toFixed(1));
        el.setAttribute('fill', 'none');
        el.setAttribute('stroke', COLORS[k.color]);
        el.setAttribute('stroke-width', k.w || 2.5);
        el.setAttribute('class', 'inkPath');
      }
    }
    el.setAttribute('data-ink-id', k.id);
    el.classList.add('inkItem');
    return el;
  }

  /* 手绘圈的平滑闭合路径（Catmull-Rom → 贝塞尔） */
  function smoothLoop(pts, w, h) {
    const p = pts.map(pt => ({ x: pt.x * w, y: pt.y * h }));
    if (p.length < 3) return '';
    let d = `M${p[0].x.toFixed(1)} ${p[0].y.toFixed(1)}`;
    for (let i = 0; i < p.length; i++) {
      const p0 = p[(i - 1 + p.length) % p.length];
      const p1 = p[i];
      const p2 = p[(i + 1) % p.length];
      const p3 = p[(i + 2) % p.length];
      const c1x = p1.x + (p2.x - p0.x) / 6, c1y = p1.y + (p2.y - p0.y) / 6;
      const c2x = p2.x - (p3.x - p1.x) / 6, c2y = p2.y - (p3.y - p1.y) / 6;
      d += ` C${c1x.toFixed(1)} ${c1y.toFixed(1)}, ${c2x.toFixed(1)} ${c2y.toFixed(1)}, ${p2.x.toFixed(1)} ${p2.y.toFixed(1)}`;
    }
    return d + ' Z';
  }

  /* ================= 撤销 / 重做 ================= */
  function snapshot() {
    return { marks: clone(S.marks), annos: clone(S.annos), ink: clone(S.ink) };
  }
  function restore(s) { S.marks = s.marks; S.annos = s.annos; S.ink = s.ink; }
  function pushUndo() { S.undo.push(snapshot()); if (S.undo.length > 60) S.undo.shift(); S.redo = []; }
  function undo() {
    if (!S.undo.length) return toast('没有可撤销的操作');
    S.redo.push(snapshot());
    restore(S.undo.pop());
    redrawAll(); toast('已撤销');
  }
  function redo() {
    if (!S.redo.length) return toast('没有可重做的操作');
    S.undo.push(snapshot());
    restore(S.redo.pop());
    redrawAll(); toast('已重做');
  }
  function redrawAll() { renderMarks(); renderInk(); }

  /* ================= 工具交互 ================= */
  function setTool(t) {
    S.tool = t;
    $$('.tool[data-tool]').forEach(b => b.classList.toggle('active', b.dataset.tool === t));
    applyInkMode();
    const tips = {
      pen: '画笔：在原文上拖动即可画线',
      circle: '画圈：按住鼠标沿要圈住的内容划一圈，松手自动闭合',
      arrow: '箭头：从起点拖到终点',
      text: '文字批注：点击原文任意位置插入标签',
      eraser: '橡皮擦：点击或按住划过笔画、圈线、箭头、荧光笔标记即可擦除'
    };
    if (tips[t]) toast(tips[t]);
  }

  function setColor(c) {
    S.color = c;
    $$('.swatch').forEach(b => b.classList.toggle('active', b.dataset.color === c));
  }

  /* --- 画笔 / 画圈 / 箭头 / 橡皮：在墨迹层上操作 --- */
  function bindInkLayer(layer) {
    let cur = null, preview = null;

    const rel = (e) => {
      const r = layer.getBoundingClientRect();
      return { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height };
    };
    const svgOf = () => layer.querySelector('svg');

    layer.addEventListener('pointerdown', e => {
      // 落笔瞬间再兜底一次样式，防止外部样式覆盖导致指针事件丢失
      applyInkMode();

      if (S.tool === 'eraser') {
        e.preventDefault();
        const hit = eraseAt(e);
        if (hit) startEraseDrag();
        return;
      }
      if (!(S.tool === 'pen' || S.tool === 'circle' || S.tool === 'arrow')) return;
      e.preventDefault();
      try { layer.setPointerCapture(e.pointerId); } catch (err) { /* 某些环境不支持捕获，靠全局监听兜底 */ }

      const para = parseInt(layer.dataset.inkLayer, 10);
      const p = rel(e);
      cur = {
        id: 'k' + Date.now() + Math.random().toString(36).slice(2, 6),
        para, type: S.tool === 'pen' ? 'pen' : (S.tool === 'circle' ? 'circle' : 'arrow'),
        color: S.color, d: [p], w: S.tool === 'pen' ? 3.2 : (S.tool === 'circle' ? 2.8 : 3.2)
      };
      S.swiping = true;
      preview = inkEl(cur, layer.clientWidth, layer.clientHeight);
      svgOf().appendChild(preview);
      S._drawing = { id: cur.id, type: cur.type, para };
    });

    layer.addEventListener('pointermove', e => {
      if (S.tool === 'eraser' && S.swiping) { eraseAt(e); return; }
      if (!cur) return;
      const p = rel(e);
      const last = cur.d[cur.d.length - 1];
      // 过滤过密采样点，减小路径体积
      if (Math.hypot(p.x - last.x, p.y - last.y) < 0.0015) return;
      if (cur.type === 'arrow') cur.d = [cur.d[0], p];
      else cur.d.push(p);
      const next = inkEl(cur, layer.clientWidth, layer.clientHeight);
      if (preview && preview.parentNode) preview.parentNode.replaceChild(next, preview);
      else svgOf().appendChild(next);
      preview = next;
    });

    const finish = () => {
      endEraseDrag();
      if (!cur) return;
      const pts = cur.d.length;
      const spread = pts > 1
        ? Math.hypot(cur.d[pts - 1].x - cur.d[0].x, cur.d[pts - 1].y - cur.d[0].y)
        : 0;
      const tiny = (cur.type === 'circle' && pts < 6) || (cur.type !== 'circle' && (pts < 2 || spread < 0.004));
      if (!tiny) {
        pushUndo();
        S.ink.push(cur);
        toast(cur.type === 'circle' ? '已画圈（可用橡皮擦除）' : (cur.type === 'arrow' ? '已添加箭头' : '已画线'));
      }
      cur = null; preview = null; S.swiping = false; S._drawing = null;
      renderInk();
      applyInkMode();
    };
    layer.addEventListener('pointerup', finish);
    layer.addEventListener('pointercancel', () => { if (cur) { cur = null; preview = null; S.swiping = false; S._drawing = null; renderInk(); applyInkMode(); } endEraseDrag(); });
    // 指针离开层时若仍按住（无捕获环境），也要结束当前笔
    layer.addEventListener('pointerleave', e => { if (e.buttons === 0 && cur) finish(); });
  }

  /* --- 橡皮擦：命中检测（不依赖 event.target，避免被上层元素吃掉） --- */
  function startEraseDrag() {
    if (S.swiping) return;
    S.swiping = true;
    pushUndo();
  }
  function endEraseDrag() {
    if (!S.swiping) return;
    S.swiping = false;
  }

  function eraseAt(e) {
    applyInkMode();
    const layer = e.currentTarget;
    const para = parseInt(layer.dataset.inkLayer, 10);

    // 1) 先把命中点上的墨迹元素找出来（兼容 pointer-events 异常的情况）
    const hitEl = document.elementFromPoint(e.clientX, e.clientY);
    let inkId = null;
    if (hitEl && layer.contains(hitEl)) {
      const g = hitEl.closest ? hitEl.closest('[data-ink-id]') : null;
      if (g) inkId = g.getAttribute('data-ink-id');
    }
    // 2) 若元素命中失败，按几何距离在附近找最近的一条笔画
    if (!inkId) inkId = nearestInk(para, e.clientX, e.clientY, 14);

    if (inkId) {
      if (!S.swiping) startEraseDrag();
      removeInk(inkId);
      toast('已擦除笔画');
      return true;
    }

    // 3) 命中文本标记（荧光笔 / 下划线）——墨迹层在橡皮模式下会压住正文，
    //    所以不能依赖 hitEl，改为按坐标在段落内定位字符，再查该字符的标记。
    const markId = markAtPoint(layer, para, e.clientX, e.clientY);
    if (markId) {
      if (!S.swiping) startEraseDrag();
      S.marks = S.marks.filter(m => m.id !== markId);
      renderMarks();
      applyInkMode();
      toast('已擦除标记');
      return true;
    }
    return false;
  }

  /* 在指定段落的文字范围内，找出坐标处所属的标记 id */
  function markAtPoint(layer, para, clientX, clientY) {
    const paraRec = paraNodes[para - 1];
    if (!paraRec) return null;
    const node = paraRec.txt;
    const walker = document.createTreeWalker(node, NodeFilter.SHOW_TEXT);
    let n, pos = 0;
    const y = clientY;
    while ((n = walker.nextNode())) {
      const len = n.nodeValue.length;
      const rng = document.createRange();
      // 粗定位：先按整节点纵向范围筛，再逐字符精确匹配
      rng.selectNodeContents(n);
      const nb = rng.getBoundingClientRect();
      if (y >= nb.top - 2 && y <= nb.bottom + 2 && clientX >= nb.left - 4 && clientX <= nb.right + 4) {
        for (let i = 0; i < len; i++) {
          rng.setStart(n, i);
          rng.setEnd(n, i + 1);
          const cb = rng.getBoundingClientRect();
          if (cb.width === 0 && cb.height === 0) continue;
          if (clientX >= cb.left - 2 && clientX <= cb.right + 2 && y >= cb.top - 3 && y <= cb.bottom + 3) {
            const abs = pos + i;
            const hit = S.marks.find(m => m.para === para && abs >= m.start && abs <= m.end);
            if (hit) return hit.id;
            break;
          }
        }
      }
      pos += len;
    }
    return null;
  }

  /* 根据屏幕坐标找最近的笔画（阈值 px） */
  function nearestInk(para, clientX, clientY, tol) {
    let best = null, bestD = tol;
    S.ink.filter(k => k.para === para).forEach(k => {
      const layer = inkLayerOf(para);
      if (!layer) return;
      const r = layer.getBoundingClientRect();
      const pts = k.type === 'circle' && k.d ? k.d : (k.d || []);
      if (!pts.length) return;
      pts.forEach(p => {
        const d = Math.hypot(r.left + p.x * r.width - clientX, r.top + p.y * r.height - clientY);
        if (d < bestD) { bestD = d; best = k.id; }
      });
      // 箭头线段中点也参与判定
      if (k.type === 'arrow' && pts.length >= 2) {
        const a = pts[0], b2 = pts[pts.length - 1];
        for (let t = 0; t <= 1; t += 0.1) {
          const mx = a.x + (b2.x - a.x) * t, my = a.y + (b2.y - a.y) * t;
          const d = Math.hypot(r.left + mx * r.width - clientX, r.top + my * r.height - clientY);
          if (d < bestD) { bestD = d; best = k.id; }
        }
      }
    });
    return best;
  }

  function removeInk(id) {
    S.ink = S.ink.filter(k => k.id !== id);
    renderInk();
  }

  /* --- 文本批注工具：点击原文插入 --- */
  let pendingAnno = null;
  function handleTextToolClick(e) {
    if (S.tool !== 'text') return;
    const en = e.target.closest('.en');
    if (!en) return;
    const para = paraIndexOfNode(en);
    if (para < 0) return;
    const pos = caretOffset(en, e.clientX, e.clientY);
    if (pos == null) return;
    pendingAnno = { para: para + 1, pos };
    const fi = $('#floatInput');
    const r = e.target.getBoundingClientRect();
    fi.classList.remove('hidden');
    fi.style.left = Math.min(e.clientX + 8, window.innerWidth - 280) + 'px';
    fi.style.top = Math.min(e.clientY + 8, window.innerHeight - 110) + 'px';
    const box = $('#floatInputBox');
    box.value = '';
    box.focus();
    void r;
  }

  function caretOffset(root, x, y) {
    let range;
    if (document.caretRangeFromPoint) range = document.caretRangeFromPoint(x, y);
    else if (document.caretPositionFromPoint) {
      const p = document.caretPositionFromPoint(x, y);
      if (!p) return null;
      range = document.createRange();
      range.setStart(p.offsetNode, p.offset);
    }
    if (!range) return null;
    if (!root.contains(range.startContainer)) return null;
    return offsetInPara(paraIndexOfNode(range.startContainer), range.startContainer, range.startOffset);
  }

  function commitAnno() {
    const v = $('#floatInputBox').value.trim();
    if (!v || !pendingAnno) { $('#floatInput').classList.add('hidden'); pendingAnno = null; return; }
    pushUndo();
    S.annos.push({ id: 'a' + Date.now(), type: 'text', para: pendingAnno.para, pos: pendingAnno.pos, text: v, color: S.color });
    pendingAnno = null;
    $('#floatInput').classList.add('hidden');
    renderAnnos();
    toast('已插入批注：' + v);
  }

  /* --- 标记：荧光笔 / 下划线 --- */
  function applyMark(type, sel) {
    if (!sel) sel = getSelectionInfo();
    if (!sel) { toast('请先选中原文中的文字，再点标记工具'); return; }
    pushUndo();
    const color = S.color;
    const push = (para, start, end) => {
      const dup = S.marks.find(m => m.para === para && m.type === type && m.start < end && m.end > start);
      if (dup) return false;
      S.marks.push({ id: 'm' + Date.now() + Math.random().toString(36).slice(2, 5), type, para, start, end, color });
      return true;
    };
    let ok;
    if (sel.single) ok = push(sel.para, sel.start, sel.end);
    else {
      const p1 = paraNodes[sel.para - 1].text.length;
      const p2 = paraNodes[sel.para2 - 1].text.length;
      ok = push(sel.para, sel.start, p1);
      push(sel.para2, 0, sel.end2);
    }
    renderMarks();
    window.getSelection().removeAllRanges();
    toast(ok ? (type === 'hl' ? '已加荧光笔标记' : '已加下划线') : '该位置已有同类标记');
  }

  /* ================= 选区浮层 ================= */
  const popover = $('#popover');
  let lastSel = null;

  function showPopover(sel) {
    lastSel = sel;
    $('#popTitle').textContent = sel.text.length > 90 ? sel.text.slice(0, 90) + '…' : sel.text;
    $('#popResult').classList.add('hidden');
    $('#popResult').innerHTML = '';
    popover.classList.remove('hidden');
    const r = sel.rect;
    const w = 340, h = popover.offsetHeight || 90;
    let left = Math.min(Math.max(8, r.left), window.innerWidth - w - 8);
    let top = r.bottom + 8;
    if (top + h > window.innerHeight - 10) top = Math.max(8, r.top - h - 8);
    popover.style.left = left + 'px';
    popover.style.top = top + 'px';
  }
  function hidePopover() {
    popover.classList.add('hidden');
    lastSel = null;
  }

  function popResult(html) {
    const el = $('#popResult');
    el.innerHTML = html;
    el.classList.remove('hidden');
    // 位置微调，避免超出屏幕
    const r = popover.getBoundingClientRect();
    if (r.bottom > window.innerHeight - 8) {
      popover.style.top = Math.max(8, window.innerHeight - popover.offsetHeight - 8) + 'px';
    }
  }

  /* --- 离线本地词库：原文核心词 + 常见高考词（教学释义） --- */
  const LOCAL_DICT = {
    'initiative': { pos: 'n.', cn: '倡议；主动性；新举措', col: 'launch / support an initiative；a longstanding initiative', note: '原文：longstanding initiatives to expand its green spaces.' },
    'initiatives': { pos: 'n.', cn: '倡议（复数）', col: 'green initiatives 环保倡议', note: '原文：longstanding initiatives to expand its green spaces.' },
    'airborne': { pos: 'adj.', cn: '空气传播的；悬浮在空中的', col: 'airborne carbon / airborne pollutants / airborne viruses', note: '原文：absorb a surprising amount of airborne carbon.' },
    'absorb': { pos: 'v.', cn: '吸收；吸引（注意力）；理解', col: 'absorb carbon dioxide / be absorbed in 专注于', note: '原文：absorb a surprising amount of airborne carbon.' },
    'habitat': { pos: 'n.', cn: '栖息地；（动植物的）生活环境', col: 'wildlife habitat / natural habitat / provide habitat for', note: '原文：provide wildlife habitat.' },
    'sweetgums': { pos: 'n.', cn: '枫香树（sweetgum 的复数）', col: 'sweetgum tree', note: '原文与 oaks 并列为纽约主要树种。' },
    'oaks': { pos: 'n.', cn: '橡树（oak 的复数）', col: 'a big old oak / oak tree', note: '原文：Oaks are keystone species.' },
    'isoprene': { pos: 'n.', cn: '异戊二烯（植物释放的挥发性有机物）', col: 'isoprene production / release isoprene', note: '原文：produce huge amounts of a chemical substance called isoprene.' },
    'nitrogen': { pos: 'n.', cn: '氮', col: 'nitrogen oxides 氮氧化物', note: '原文：polluting nitrogen oxides released by vehicles, buildings and industry.' },
    'oxides': { pos: 'n.', cn: '氧化物（oxide 的复数）', col: 'nitrogen oxides / carbon oxides', note: '原文：polluting nitrogen oxides.' },
    'ozone': { pos: 'n.', cn: '臭氧', col: 'ground-level ozone 地面臭氧 / the ozone layer 臭氧层', note: '原文给出了中文注释（臭氧）。' },
    'interacts': { pos: 'v.', cn: '相互作用（interact 三单）', col: 'interact with sth / interact rapidly with', note: '原文：isoprene interacts rapidly with polluting nitrogen oxides.' },
    'interact': { pos: 'v.', cn: '相互作用；交流', col: 'interact with sb/sth', note: '原文：isoprene interacts rapidly with polluting nitrogen oxides.' },
    'pollutants': { pos: 'n.', cn: '污染物', col: 'remove pollutants / air pollutants', note: '原文：remove tiny pollutants.' },
    'species': { pos: 'n.', cn: '物种（单复数同形）', col: 'keystone species / endangered species / species patterns', note: '原文：maintains past species patterns in new plantings.' },
    'plantings': { pos: 'n.', cn: '种植；新植的树木', col: 'new plantings 新植树木', note: '原文：past species patterns in new plantings.' },
    'maintains': { pos: 'v.', cn: '维持；坚持认为（maintain 三单）', col: 'maintain a balance / maintain that ...', note: '原文：if the city maintains past species patterns.' },
    'oblivious': { pos: 'adj.', cn: '未察觉的；不在意的', col: 'be oblivious to / of sth', note: '原文：The Parks Department is not oblivious to the issue.（双重否定 = 知道）' },
    'century': { pos: 'n.', cn: '世纪', col: 'in coming decades 在未来几十年', note: '原文：in coming decades.' },
    'decades': { pos: 'n.', cn: '十年（decade 的复数）', col: 'in coming decades / for decades', note: '原文：in coming decades.' },
    'keystone': { pos: 'adj./n.', cn: '拱心石；关键（keystone species 关键种）', col: 'keystone species', note: '原文：Oaks are keystone species.' },
    'coauthor': { pos: 'n.', cn: '合著者', col: 'study coauthor', note: '原文：said study coauthor Róisín Commane.' },
    'researchers': { pos: 'n.', cn: '研究人员', col: 'a team of researchers', note: '原文：some of its researchers.' },
    'concluded': { pos: 'v.', cn: '得出结论；结束（conclude 过去式）', col: 'conclude that ... / conclude a speech', note: '原文：concluded that city trees did release isoprene.' },
    'atmosphere': { pos: 'n.', cn: '大气；氛围', col: 'the atmosphere / a relaxed atmosphere', note: '教学补充词（原文未出现），与本篇气体话题相关。' },
    'evidence': { pos: 'n.', cn: '证据', col: 'evidence for/of sth / clear evidence that ...', note: '教学补充词（原文未出现），阅读题高频。' },
    'reduce': { pos: 'v.', cn: '减少；降低', col: 'reduce carbon emissions / reduce the risk of', note: '教学补充词（原文未出现），可替换 lower。' },
    'emission': { pos: 'n.', cn: '排放（物）', col: 'carbon emissions / cut emissions', note: '教学补充词（原文未出现），与本篇污染话题相关。' }
  };

  const SYNS = {
    'account for': '占据（比例）；解释 ≈ make up / constitute / explain',
    'oblivious to': '未察觉 ≈ unaware of / ignorant of / not aware of',
    'keystone species': '关键种：生态系统中影响其他物种存续的关键物种',
    'interact with': '与……相互作用 ≈ react with / combine with',
    'ground-level ozone': '地面臭氧（近地面，对人体有害，与高空臭氧层不同）',
    'car-centric': '以汽车为中心的（car + centric，构词：centric 以……为中心）',
    'airborne': '空气传播的（air + borne，borne 为 bear 的过去分词）',
    'longstanding': '长期存在的（long + standing，复合形容词）',
    'plantings': '种植（活动/新植树），plant + -ing',
    'coauthor': '合著者（co- 共同 + author）'
  };

  /* --- 本地翻译词典（句中短语级，供离线兜底） --- */
  const TRANS = {
    'harmless by itself': '本身无害',
    'interacts rapidly with': '与……迅速发生反应',
    'ground-level ozone': '地面臭氧',
    'a major factor in': '……的一个重要因素',
    'breathing problems': '呼吸问题',
    'in line with': '与……一致；依照',
    'tens of thousands of': '数以万计',
    'lower surface temperatures': '降低地表温度',
    'wildlife habitat': '野生动物栖息地',
    'account for': '占据（比例）',
    'a new study': '一项新研究',
    'keystone species': '关键种',
    'air quality': '空气质量',
    'make a big deal of': '把……当回事；大肆宣扬',
    'in coming decades': '在未来几十年',
    'car-centric': '以汽车为中心的',
    'go up by': '上升了（幅度）',
    'as much as': '高达；多达'
  };

  /* ================= 浮动层动作 ================= */
  popover.addEventListener('click', e => {
    const b = e.target.closest('button[data-act]');
    if (!b || !lastSel) return;
    const act = b.dataset.act;
    const q = lastSel.text;

    if (act === 'dict') {
      window.open('https://www.oxfordlearnersdictionaries.com/definition/english/' + encodeURIComponent(q.toLowerCase().split(/\s+/)[0]), '_blank', 'noopener');
      popResult('<div class="pr-label">已在新标签打开</div>牛津学习者词典查询：<b>' + esc(q) + '</b><br><span class="pr-warn">若浏览器拦截弹窗，请允许弹窗后重试；也可直接用下方本地词条。</span>');
      return;
    }
    if (act === 'dict-cn') {
      window.open('https://dict.youdao.com/result?word=' + encodeURIComponent(q) + '&lang=en', '_blank', 'noopener');
      return;
    }
    if (act === 'cn') {
      const key = normKey(q);
      const d = LOCAL_DICT[key];
      if (d) {
        popResult('<div class="pr-label">本地词库 · 教学释义</div><b>' + esc(q) + '</b> <span style="color:#8494AC">' + d.pos + '</span><br>' + d.cn +
          '<br><br><span style="color:#8494AC">搭配：</span>' + d.col + '<br><span style="color:#8494AC">说明：</span>' + d.note +
          '<br><br><span class="pr-warn">本地词库仅覆盖原文核心词与常见高考词，其余词请点“查词典”。</span>');
      } else if (SYNS[key]) {
        popResult('<div class="pr-label">本地词库 · 短语释义</div><b>' + esc(q) + '</b><br>' + SYNS[key]);
      } else {
        popResult('<div class="pr-label">本地词库</div><span class="pr-warn">本地词库未收录「' + esc(q) + '」。</span><br>可点“查词典”打开牛津/有道在线查询，或选中单词后查看右侧题目解析中的词汇说明。');
      }
      return;
    }
    if (act === 'syn') {
      const key = normKey(q);
      const s = SYNS[key];
      if (s) popResult('<div class="pr-label">搭配 / 近义</div>' + s);
      else {
        const d = LOCAL_DICT[key];
        if (d) popResult('<div class="pr-label">搭配</div>' + d.col);
        else popResult('<div class="pr-label">搭配 / 近义</div><span class="pr-warn">本地库暂无该词条，可先查词典，再由教师口头补充搭配。</span>');
      }
      return;
    }
    if (act === 'trans') {
      popResult('<div class="pr-label">正在翻译…</div>');
      translate(q).then(txt => {
        popResult('<div class="pr-label">中文翻译</div>' + txt);
      });
      return;
    }
    if (act === 'copy') {
      navigator.clipboard.writeText(q).then(() => {
        popResult('<div class="pr-label">已复制</div>' + esc(q.slice(0, 120)));
        toast('已复制到剪贴板');
      }).catch(() => {
        popResult('<div class="pr-label">复制失败</div><span class="pr-warn">浏览器未授权剪贴板，请手动选中后 Ctrl+C。</span>');
      });
      return;
    }
    if (act === 'send') {
      sendToSentenceLab(q);
      return;
    }
    if (act === 'mark-hl') { applyMark('hl', lastSel); hidePopover(); return; }
    if (act === 'mark-ul') { applyMark('ul', lastSel); hidePopover(); return; }
  });

  function normKey(q) {
    return q.toLowerCase().replace(/[.,;:!?"“”'’()（）—–-]/g, '').replace(/\s+/g, ' ').trim();
  }

  function esc(s) { return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }

  /* --- 翻译：在线 API 优先，失败则本地术语表兜底 --- */
  async function translate(text) {
    const endpoints = [
      'https://api.mymemory.translated.net/get?q=' + encodeURIComponent(text.slice(0, 480)) + '&langpair=en|zh-CN'
    ];
    for (const url of endpoints) {
      try {
        const ctrl = new AbortController();
        const t = setTimeout(() => ctrl.abort(), 6000);
        const res = await fetch(url, { signal: ctrl.signal });
        clearTimeout(t);
        if (!res.ok) continue;
        const data = await res.json();
        const out = data?.responseData?.translatedText;
        if (out && !/MYMEMORY WARNING|QUERY LENGTH LIMIT/i.test(out)) {
          return esc(out) + '<br><span style="color:#8494AC;font-size:11px">来源：MyMemory 在线翻译（外部服务）</span>';
        }
      } catch (err) { /* 继续尝试兜底 */ }
    }
    // 本地兜底：术语/短语表逐条替换
    let out = '', rest = text, hit = 0;
    const keys = Object.keys(TRANS).sort((a, b) => b.length - a.length);
    keys.forEach(k => {
      const re = new RegExp(k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
      if (re.test(rest)) { rest = rest.replace(re, '【' + TRANS[k] + '】'); hit++; }
    });
    if (hit > 0) {
      out = '（在线翻译不可用 · 本地短语翻译）<br>' + esc(rest);
    } else {
      out = '<span class="pr-warn">在线翻译服务当前不可访问（网络或跨域限制），本地短语表也未匹配到该片段。</span><br>' +
        '替代方案：①选中单词用“查词典”打开有道/牛津；②使用右侧题目解析中的中文释义；③改用另一个翻译服务查阅。';
    }
    return out;
  }

  /* ================= 长难句分析台已移除 =================
     保留一个空实现，避免浮层里残留的旧入口报错。
     原“发送至长难句分析台”改为“复制原句”，教师可自行粘贴到需要的地方。 */
  function sendToSentenceLab(text) {
    navigator.clipboard.writeText(text).then(() => {
      toast('已复制原句（长难句分析台已按你的要求移除）');
    }).catch(() => {
      toast('复制失败，请手动选中原句后 Ctrl+C');
    });
    hidePopover();
  }

  /* ================= 右栏 ================= */
  const qnav = $('#qnav');
  function buildNav() {
    qnav.innerHTML = '';
    window.QUESTIONS.forEach(q => {
      const b = document.createElement('button');
      b.dataset.q = q.id;
      b.textContent = 'Q' + q.no;
      b.classList.toggle('active', S.current === q.id);
      b.addEventListener('click', () => selectQuestion(q.id));
      qnav.appendChild(b);
    });
    const s = document.createElement('button');
    s.dataset.q = 'summary';
    s.className = 'summaryBtn';
    s.textContent = '课末总结';
    s.addEventListener('click', () => selectQuestion('summary'));
    qnav.appendChild(s);
  }

  function selectQuestion(id) {
    S.current = id;
    $$('#qnav button').forEach(b => b.classList.toggle('active', b.dataset.q === id));
    $$('#qnav button.summaryBtn').forEach(b => b.classList.toggle('active', id === 'summary'));
    if (id === 'summary') { renderSummary(); $('#questionView').classList.add('hidden'); $('#summaryView').classList.remove('hidden'); }
    else { $('#summaryView').classList.add('hidden'); $('#questionView').classList.remove('hidden'); renderQuestion(id); }
    $('#rightScroll').scrollTop = 0;
    renderEvidence();
    hidePopover();
  }

  const PANEL_IDS = ['guide', 'evidence', 'reason', 'distractors'];

  function renderQuestion(id) {
    const q = window.QUESTIONS.find(x => x.id === id);
    const st = S.revealed[id] || (S.revealed[id] = {});
    const hv = $('#questionView');
    hv.innerHTML = '';

    const head = document.createElement('div');
    head.className = 'qHead';
    head.innerHTML = `
      <div class="qKicker">QUESTION ${q.no} · 阅读理解 C 篇</div>
      <div class="qStem">${esc(q.stem)}</div>
      <span class="qType">${esc(q.type)}</span>`;
    hv.appendChild(head);

    // 选项
    const opts = document.createElement('div');
    opts.className = 'opts';
    Object.entries(q.options).forEach(([k, v]) => {
      const d = document.createElement('div');
      d.className = 'opt';
      d.dataset.opt = k;
      d.innerHTML = `<span class="k">${k}</span><span class="t">${esc(v)}</span>`;
      opts.appendChild(d);
      d.addEventListener('click', () => toast('选项 ' + k + '：教师可先让学生说明依据，再点“显示答案”核对'));
    });
    hv.appendChild(opts);

    // 控制按钮
    const ctrl = document.createElement('div');
    ctrl.className = 'ctrlRow';
    ctrl.innerHTML = `
      <button class="ctrl locate" data-ctrl="locate">⌕ 定位证据</button>
      <button class="ctrl" data-ctrl="guide">① 读题审题</button>
      <button class="ctrl" data-ctrl="evidence">② 证据解释</button>
      <button class="ctrl" data-ctrl="reason">③ 推理过程</button>
      <button class="ctrl" data-ctrl="distractors">④ 干扰项</button>
      <button class="ctrl" data-ctrl="all">全部展开</button>
      <button class="ctrl answerBtn" data-ctrl="answer">显示答案</button>`;
    hv.appendChild(ctrl);

    // 面板
    const panels = document.createElement('div');
    panels.innerHTML = `
      <div class="panel guide collapsed" data-panel="guide">
        <div class="panelHead">① 读题审题 · 考查什么 <span class="arrow">▾</span></div>
        <div class="panelBody">
          <div><b>能力类型：</b>${esc(q.type)}</div>
          <div style="margin-top:5px"><b>题干关键词：</b>${esc(q.typeFocus)}</div>
          <div style="margin-top:5px"><b>定位范围：</b>${q.paraFocus.map(p => '¶' + p).join(' + ')}</div>
          <div style="margin-top:5px"><b>答案性质：</b>${esc(q.answerBasis)}（本次使用的答案来自教学推断，请与官方参考答案核对）</div>
        </div>
      </div>
      <div class="panel ev collapsed" data-panel="evidence">
        <div class="panelHead">② 原文证据（点击“定位”左栏跳转并高亮） <span class="arrow">▾</span></div>
        <div class="panelBody"></div>
      </div>
      <div class="panel reason collapsed" data-panel="reason">
        <div class="panelHead">③ 推理过程 · 原文 → 选项 <span class="arrow">▾</span></div>
        <div class="panelBody"><div class="steps"></div></div>
      </div>
      <div class="panel dis collapsed" data-panel="distractors">
        <div class="panelHead">④ 干扰项分析 <span class="arrow">▾</span></div>
        <div class="panelBody"></div>
      </div>
      <div class="strategyBox"><b>阅读策略：</b>${esc(q.strategy)}</div>`;
    hv.appendChild(panels);

    // 证据内容
    const evBody = $('.panel[data-panel="evidence"] .panelBody', panels);
    q.evidence.forEach(ev => {
      const d = document.createElement('div');
      d.className = 'evItem';
      d.innerHTML = `<div class="evTop"><span class="evTag">${ev.tag}</span><span class="evPara">¶${ev.para}</span>
        <button class="evLocate" data-ev="${ev.tag}">定位 →</button></div>
        <div class="evQuote">“${esc(ev.text)}”</div>
        <div class="evCn">${esc(ev.cn)}</div>`;
      evBody.appendChild(d);
    });

    // 推理
    const steps = $('.steps', panels);
    q.reasoning.forEach((s, i) => {
      const d = document.createElement('div');
      d.className = 'step';
      d.innerHTML = `<div class="stepNo">${i + 1}</div><div class="stepBody"><div class="stepName">${esc(s.step)}</div><div class="stepText">${esc(s.text)}</div></div>`;
      steps.appendChild(d);
    });

    // 干扰项
    const disBody = $('.panel[data-panel="distractors"] .panelBody', panels);
    q.distractors.forEach(d0 => {
      const d = document.createElement('div');
      d.className = 'disItem';
      d.innerHTML = `<div class="disK">${d0.key}</div><div class="disBody"><div class="disV">${esc(d0.verdict)}</div><div class="disT">${esc(d0.text)}</div></div>`;
      disBody.appendChild(d);
    });

    // 答案区（默认隐藏）
    const ansWrap = document.createElement('div');
    ansWrap.id = 'answerWrap';
    hv.appendChild(ansWrap);
    renderAnswerState(q, st);

    // 事件绑定
    ctrl.addEventListener('click', e => {
      const b = e.target.closest('[data-ctrl]');
      if (!b) return;
      const act = b.dataset.ctrl;
      if (act === 'locate') { locateEvidence(q); b.classList.add('on'); setTimeout(() => b.classList.remove('on'), 1200); return; }
      if (act === 'all') {
        PANEL_IDS.forEach(p => openPanel(p, true));
        syncCtrl();
        toast('已展开全部解析');
        return;
      }
      if (act === 'answer') { toggleAnswer(q); return; }
      togglePanel(act);
      syncCtrl();
    });

    $$('.panelHead', panels).forEach(h => {
      h.addEventListener('click', () => {
        const p = h.parentElement;
        p.classList.toggle('collapsed');
        syncCtrl();
      });
    });

    $$('.evLocate', panels).forEach(b => {
      b.addEventListener('click', () => locateEvidence(q, b.dataset.ev));
    });

    function syncCtrl() {
      PANEL_IDS.forEach(p => {
        const on = !$(`.panel[data-panel="${p}"]`, panels).classList.contains('collapsed');
        const btn = $(`[data-ctrl="${p}"]`, ctrl);
        if (btn) btn.classList.toggle('on', on);
      });
      const ab = $('[data-ctrl="answer"]', ctrl);
      const revealed = !!(S.revealed[S.current] || {}).ans;
      ab.classList.toggle('on', revealed);
      ab.textContent = revealed ? '隐藏答案' : '显示答案';
    }
    function togglePanel(p) {
      const el = $(`.panel[data-panel="${p}"]`, panels);
      if (el) el.classList.toggle('collapsed');
    }
    function openPanel(p, open) {
      const el = $(`.panel[data-panel="${p}"]`, panels);
      if (el) el.classList.toggle('collapsed', !open);
    }
    hv._syncCtrl = syncCtrl;
    syncCtrl();
    st._sync = syncCtrl;
  }

  function renderAnswerState(q, st) {
    const wrap = $('#answerWrap');
    if (!wrap) return;
    if (!st.ans) {
      wrap.innerHTML = `<div class="hiddenAnswer">答案已隐藏 · 先让学生说出依据，再点上方“显示答案”</div>`;
      $$('#questionView .opt').forEach(o => { o.classList.remove('correct', 'wrong'); const f = o.querySelector('.flag'); if (f) f.remove(); });
      return;
    }
    wrap.innerHTML = `<div class="answerBanner">
        <div class="big">${q.answer}</div>
        <div><div class="txt">正确选项：${q.answer} — ${esc(q.options[q.answer])}</div>
        <div class="basis">${esc(q.answerBasis)}</div></div>
      </div>`;
    $$('#questionView .opt').forEach(o => {
      const k = o.dataset.opt;
      o.classList.toggle('correct', k === q.answer);
      const old = o.querySelector('.flag'); if (old) old.remove();
      if (k === q.answer) {
        const f = document.createElement('span'); f.className = 'flag okflag'; f.textContent = '正确答案'; o.appendChild(f);
      } else {
        const dis = q.distractors.find(d => d.key === k);
        if (dis) { const f = document.createElement('span'); f.className = 'flag'; f.textContent = dis.verdict; o.appendChild(f); }
      }
    });
  }

  function toggleAnswer(q) {
    const st = S.revealed[q.id];
    st.ans = !st.ans;
    if (st.ans) {
      PANEL_IDS.forEach(p => {
        const el = $(`.panel[data-panel="${p}"]`);
        if (el) el.classList.remove('collapsed');
      });
      renderAnswerState(q, st);
      if (st._sync) st._sync();
    } else {
      renderAnswerState(q, st);
      if (st._sync) st._sync();
    }
  }

  /* --- 定位证据：右栏→左栏滚动 + 同步高亮 --- */
  function locateEvidence(q, tag) {
    S.evidenceOn = true;
    renderEvidence();
    const ev = tag ? q.evidence.find(e => e.tag === tag) : q.evidence[0];
    if (!ev) return;
    markParaActive(ev.para);
    // 滚动到该段落中的证据位置
    const para = paraNodes[ev.para - 1].el;
    const marks = $$('mark.ev', para);
    const target = marks[tag ? 0 : 0] || para;
    const leftScroll = $('#leftScroll');
    const offset = target.getBoundingClientRect().top - leftScroll.getBoundingClientRect().top + leftScroll.scrollTop - 120;
    leftScroll.scrollTo({ top: Math.max(0, offset), behavior: 'smooth' });
    (marks.length ? marks : [para]).forEach(m => {
      m.classList.remove('flash');
      void m.offsetWidth;
      m.classList.add('flash');
    });
    toast('已定位：' + ev.tag + '（¶' + ev.para + '）');
  }

  function markParaActive(p) {
    $$('.para', passageEl).forEach(el => el.classList.toggle('paraActive', el.dataset.para == p));
  }

  /* ================= 课末总结 ================= */
  function renderSummary() {
    const v = $('#summaryView');
    const sum = window.SUMMARY;
    let html = `<div class="sumHead"><h2>课末总结 · 文章逻辑与阅读策略</h2>
      <p class="hint">只做结构与策略梳理；核心词汇搭配在左栏原文下方的词汇区完成。</p></div>`;
    html += `<div class="panel guide"><div class="panelHead">① 文章逻辑图 <span class="arrow">▾</span></div><div class="panelBody">
      <p class="hint" style="margin-bottom:8px">点击任一节点可回到原文对应段落。</p><div class="flow">`;
    sum.logic.forEach((n, i) => {
      html += `<div class="flowNode k-${n.color}" data-para="${n.para.replace('¶', '')}">
        <div class="fnTop"><span class="fKey">${n.key}</span><span class="fPara">${n.para} · ${n.basis}</span></div>
        <div class="fTitle">${esc(n.title)}</div><div class="fEn">${esc(n.en)}</div></div>`;
      if (i < sum.logic.length - 1) html += `<div class="flowArrow">▼</div>`;
    });
    html += `</div></div></div>`;
    html += `<div class="panel reason"><div class="panelHead">② 阅读策略总结（对应 Q28–Q31） <span class="arrow">▾</span></div><div class="panelBody">`;
    sum.strategies.forEach(s => {
      html += `<div class="stratItem"><div class="stratQ">${s.q}</div><div><b>${esc(s.title)}</b><br>${esc(s.text)}</div></div>`;
    });
    html += `</div></div>`;
    html += `<div class="panel dis"><div class="panelHead">③ 课末任务 <span class="arrow">▾</span></div><div class="panelBody"><ul class="taskList">`;
    sum.tasks.forEach(t => html += `<li>${esc(t)}</li>`);
    html += `</ul><p class="hint" style="margin-top:8px">任务在左栏原文下方：<b>蓝色区</b>阅读词汇连线（8 项）、<b>珊瑚区</b>写作词汇翻译（6 项）。</p></div></div>`;
    v.innerHTML = html;

    $$('.flowNode', v).forEach(n => {
      n.addEventListener('click', () => {
        const p = n.dataset.para;
        markParaActive(p);
        $('#leftScroll').scrollTo({ top: paraNodes[p - 1].el.offsetTop - 60, behavior: 'smooth' });
        toast('已回到 ¶' + p);
      });
    });
    $$('.panelHead', v).forEach(h => h.addEventListener('click', () => h.parentElement.classList.toggle('collapsed')));
  }

  /* ================= 词汇区：连线匹配 ================= */
  function buildMatch() {
    const L = $('#matchLeft'), R = $('#matchRight');
    L.innerHTML = ''; R.innerHTML = '';
    const words = window.READING_WORDS;
    const zhOrder = shuffle(words.map((w, i) => ({ ...w, idx: i })));

    words.forEach(w => {
      const b = document.createElement('button');
      b.className = 'mItem en';
      b.dataset.en = w.id;
      b.dataset.idx = words.findIndex(x => x.id === w.id);
      b.textContent = w.en;
      b.addEventListener('click', () => pickMatch(b, 'en'));
      L.appendChild(b);
    });
    zhOrder.forEach(w => {
      const b = document.createElement('button');
      b.className = 'mItem zh';
      b.dataset.zh = w.id;
      b.dataset.idx = words.findIndex(x => x.id === w.id);
      b.textContent = w.zh;
      b.addEventListener('click', () => pickMatch(b, 'zh'));
      R.appendChild(b);
    });
    setTimeout(drawLines, 60);
    updateMatchResult();
  }

  function shuffle(a) {
    const r = a.slice();
    for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; }
    return r;
  }

  function pickMatch(el, side) {
    if (el.classList.contains('done')) return;
    const m = S.match;
    if (side === 'en') {
      if (m.selEn) m.selEn.classList.remove('sel');
      m.selEn = el; el.classList.add('sel');
    } else {
      if (m.selZh) m.selZh.classList.remove('sel');
      m.selZh = el; el.classList.add('sel');
    }
    if (m.selEn && m.selZh) checkMatch();
  }

  function checkMatch() {
    const m = S.match;
    const en = m.selEn, zh = m.selZh;
    m.selEn = null; m.selZh = null;
    en.classList.remove('sel'); zh.classList.remove('sel');
    if (en.dataset.idx === zh.dataset.idx) {
      en.classList.add('done'); zh.classList.add('done');
      m.done[en.dataset.en] = zh.dataset.zh;
      m.count++;
      drawLines();
      updateMatchResult();
      if (m.count === window.READING_WORDS.length) {
        const acc = Math.round((m.count / (m.count + Object.keys(m.wrong).length)) * 100);
        $('#matchResult').classList.add('ok');
        toast('全部配对完成，正确率 ' + acc + '%');
      }
    } else {
      m.wrong[en.dataset.en + zh.dataset.zh] = true;
      en.classList.add('wrong'); zh.classList.add('wrong');
      setTimeout(() => { en.classList.remove('wrong'); zh.classList.remove('wrong'); }, 420);
      const w = window.READING_WORDS.find(x => x.id === en.dataset.en);
      toast('配对不正确 · 提示：' + w.hint);
    }
  }

  function drawLines() {
    const svg = $('#matchLines');
    const wrap = svg.parentElement;
    const wr = wrap.getBoundingClientRect();
    svg.setAttribute('viewBox', `0 0 ${wr.width} ${wr.height}`);
    svg.innerHTML = '';
    Object.entries(S.match.done).forEach(([enId]) => {
      const a = $(`.mItem.en[data-en="${enId}"]`);
      const b = $(`.mItem.zh[data-zh="${enId}"]`);
      if (!a || !b) return;
      const ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect();
      const x1 = ra.right - wr.left, y1 = ra.top + ra.height / 2 - wr.top;
      const x2 = rb.left - wr.left, y2 = rb.top + rb.height / 2 - wr.top;
      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      const mid = (x1 + x2) / 2;
      path.setAttribute('d', `M${x1} ${y1} C${mid} ${y1}, ${mid} ${y2}, ${x2} ${y2}`);
      path.setAttribute('stroke', '#12B886');
      path.setAttribute('stroke-width', '2.5');
      path.setAttribute('fill', 'none');
      path.setAttribute('stroke-linecap', 'round');
      svg.appendChild(path);
    });
  }

  function updateMatchResult() {
    const m = S.match;
    const total = window.READING_WORDS.length;
    const wrongN = Object.keys(m.wrong).length;
    $('#matchResult').textContent = `已完成 ${m.count} / ${total}` + (m.count ? ` · 配对错误 ${wrongN} 次` : ' · 尚未开始');
    $('#matchResult').classList.toggle('ok', m.count === total);
  }

  function resetMatch() {
    S.match = { selEn: null, selZh: null, done: {}, wrong: {}, count: 0 };
    buildMatch();
    $('#matchResult').classList.remove('ok');
  }

  function showMatchAnswers() {
    pushUndo();
    const m = S.match;
    window.READING_WORDS.forEach(w => {
      const a = $(`.mItem.en[data-en="${w.id}"]`);
      const b = $(`.mItem.zh[data-zh="${w.id}"]`);
      if (a && !a.classList.contains('done')) { a.classList.add('revealed'); a.classList.add('done'); }
      if (b && !b.classList.contains('done')) { b.classList.add('revealed'); b.classList.add('done'); }
      if (!m.done[w.id]) { m.done[w.id] = w.id; m.count++; }
    });
    drawLines();
    updateMatchResult();
    $('#matchResult').classList.add('ok');
    toast('已显示全部配对答案（可用“重置练习”重新作答）');
  }

  /* ================= 词汇区：写作翻译 ================= */
  function buildWriting() {
    const list = $('#writeList');
    list.innerHTML = '';
    window.WRITING_ITEMS.forEach((it, i) => {
      const d = document.createElement('div');
      d.className = 'writeItem';
      d.innerHTML = `<div class="wq">${i + 1}. ${esc(it.cn)}<span class="src">${esc(it.source)}</span></div>
        <div class="writeRow">
          <input type="text" placeholder="写出英文表达…" spellcheck="false" data-id="${it.id}">
          <button class="wBtn" data-ans="${it.id}">参考答案</button>
          <button class="wBtn ghost" data-clr="${it.id}">清空</button>
        </div>
        <div class="wAnswer hidden" id="ans-${it.id}"></div>`;
      list.appendChild(d);
      d.addEventListener('click', e => {
        const b = e.target.closest('[data-ans],[data-clr]');
        if (!b) return;
        if (b.dataset.clr) { $(`input[data-id="${b.dataset.clr}"]`).value = ''; updateWriteResult(); return; }
        const box = $('#ans-' + b.dataset.ans);
        const item = window.WRITING_ITEMS.find(x => x.id === b.dataset.ans);
        if (box.classList.contains('hidden')) {
          box.innerHTML = '<b>参考答案（多种表达均可）：</b><br>' + item.answers.map((a, k) => (k + 1) + '. ' + esc(a)).join('<br>') +
            `<span class="tip"><i>提醒：</i>${esc(item.tip)}</span>`;
          box.classList.remove('hidden');
          b.textContent = '收起答案';
        } else {
          box.classList.add('hidden');
          b.textContent = '参考答案';
        }
      });
      d.querySelector('input').addEventListener('input', updateWriteResult);
    });
    updateWriteResult();
  }

  function updateWriteResult() {
    const inputs = $$('#writeList input');
    const filled = inputs.filter(i => i.value.trim()).length;
    const el = $('#writeResult');
    el.textContent = `已填 ${filled} / ${inputs.length}`;
    el.classList.toggle('ok', filled === inputs.length);
  }

  /* ================= 批注：清除 / 导出 ================= */
  function clearPara() {
    const p = S.lastPara;
    const before = S.marks.length + S.annos.length + S.ink.length;
    pushUndo();
    S.marks = S.marks.filter(m => m.para !== p);
    S.annos = S.annos.filter(a => a.para !== p);
    S.ink = S.ink.filter(k => k.para !== p);
    const after = S.marks.length + S.annos.length + S.ink.length;
    redrawAll();
    toast(after < before ? `已清除 ¶${p} 的批注（可撤销）` : `¶${p} 没有批注`);
  }

  function clearAll() {
    if (!S.marks.length && !S.annos.length && !S.ink.length && !S.evidenceOn) { toast('当前没有可清除的批注'); return; }
    pushUndo();
    S.marks = []; S.annos = []; S.ink = []; S.evidenceOn = false;
    redrawAll();
    toast('已清除全部批注（可撤销）');
  }

  function exportAnnotations() {
    const lines = [];
    lines.push('2026 全国Ⅰ卷 · 阅读 C 篇｜课堂批注导出');
    lines.push('导出时间：' + new Date().toLocaleString('zh-CN'));
    lines.push('说明：原文逐字取自原卷；下方“教师批注”为本节课的课堂标记，非原卷内容。');
    lines.push('');
    lines.push('【一、原文（原卷）】');
    window.PASSAGE.paragraphs.forEach((p, i) => lines.push(`¶${i + 1} ${p}`));
    lines.push('');
    lines.push('【二、教师批注】');
    const byPara = {};
    S.marks.forEach(m => { (byPara[m.para] = byPara[m.para] || []).push({ kind: m.type === 'hl' ? '荧光笔' : '下划线', color: m.color, text: paraNodes[m.para - 1].text.slice(m.start, m.end) }); });
    S.annos.forEach(a => { (byPara[a.para] = byPara[a.para] || []).push({ kind: '文字批注', color: a.color, text: '@位置' + a.pos + '：' + a.text }); });
    S.ink.forEach(k => { (byPara[k.para] = byPara[k.para] || []).push({ kind: { pen: '画笔', circle: '画圈', arrow: '箭头' }[k.type], color: k.color, text: '（图形批注，见页面）' }); });
    Object.keys(byPara).sort((a, b) => a - b).forEach(p => {
      lines.push(`¶${p}`);
      byPara[p].forEach(x => lines.push(`  - [${x.kind}·${x.color}] ${x.text}`));
    });
    if (!Object.keys(byPara).length) lines.push('（本节未添加批注）');
    lines.push('');
    lines.push('【三、说明】');
    lines.push('- 当前版本不提供刷新后自动保存；刷新页面会清空批注，请用本导出文件留存。');
    lines.push('- 本文件中的批注为教学解析，不属于原卷内容。');
    const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = '阅读C篇-课堂批注-' + new Date().toISOString().slice(0, 10) + '.txt';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 3000);
    toast('已导出课堂批注（.txt）');
  }

  /* ================= 提示 ================= */
  let toastTimer;
  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 2200);
  }

  /* ================= 缩放 ================= */
  function setFont(delta) {
    S.fontSize = Math.min(24, Math.max(14, S.fontSize + delta));
    passageEl.style.setProperty('--fs', S.fontSize + 'px');
    $('#zoomVal').textContent = S.fontSize + 'px';
    requestAnimationFrame(() => { renderAnnos(); renderInk(); });
  }

  /* ================= 事件绑定 ================= */
  function bindUI() {
    $$('.tool[data-tool]').forEach(b => b.addEventListener('click', () => setTool(b.dataset.tool)));
    $$('.tool[data-mark]').forEach(b => b.addEventListener('click', () => applyMark(b.dataset.mark)));
    $$('.swatch').forEach(b => b.addEventListener('click', () => setColor(b.dataset.color)));
    $('#btnUndo').addEventListener('click', undo);
    $('#btnRedo').addEventListener('click', redo);
    $('#btnClearPara').addEventListener('click', clearPara);
    $('#btnClearAll').addEventListener('click', clearAll);
    $('#btnExport').addEventListener('click', exportAnnotations);
    $('#zoomIn').addEventListener('click', () => setFont(1));
    $('#zoomOut').addEventListener('click', () => setFont(-1));
    $('#btnFullscreen').addEventListener('click', () => {
      if (!document.fullscreenElement) document.documentElement.requestFullscreen?.().catch(() => toast('浏览器未允许全屏，可按 F11'));
      else document.exitFullscreen?.();
    });

    // 清空/撤销快捷键
    document.addEventListener('keydown', e => {
      const tag = (e.target.tagName || '').toLowerCase();
      if (tag === 'input' || tag === 'textarea') return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? redo() : undo(); }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); }
      if (e.key === 'Escape') { hidePopover(); $('#floatInput').classList.add('hidden'); pendingAnno = null; }
    });

    // 选区浮层
    passageEl.addEventListener('mouseup', e => {
      if (S.tool !== 'select') return;
      setTimeout(() => {
        const sel = getSelectionInfo();
        if (!sel) { hidePopover(); return; }
        showPopover(sel);
      }, 10);
    });
    passageEl.addEventListener('mouseup', e => {
      // 记录最近段落，供“清当前段”使用
      const p = paraIndexOfNode(e.target);
      if (p >= 0) S.lastPara = p + 1;
    });

    // 文字批注工具点击
    passageEl.addEventListener('click', handleTextToolClick);
    $('#floatOk').addEventListener('click', commitAnno);
    $('#floatCancel').addEventListener('click', () => { $('#floatInput').classList.add('hidden'); pendingAnno = null; });
    $('#floatInputBox').addEventListener('keydown', e => {
      if (e.key === 'Enter') commitAnno();
      if (e.key === 'Escape') { $('#floatInput').classList.add('hidden'); pendingAnno = null; }
    });

    // 点击文字批注标签 → 删除
    passageEl.addEventListener('click', e => {
      const badge = e.target.closest('.textAnno');
      if (!badge) return;
      if (!confirm('删除这条文字批注？')) return;
      pushUndo();
      S.annos = S.annos.filter(a => a.id !== badge.dataset.annoId);
      renderAnnos();
      toast('已删除批注');
    });

    // 橡皮擦点击标记
    passageEl.addEventListener('click', e => {
      if (S.tool !== 'eraser') return;
      const mark = e.target.closest('mark.hl, span.ul');
      if (!mark) return;
      pushUndo();
      S.marks = S.marks.filter(m => m.id !== mark.dataset.markId);
      renderMarks();
      toast('已擦除标记');
    });

    // 全局兜底：鼠标在段落外松开时，结束当前笔画
    window.addEventListener('pointerup', () => { S.swiping = false; }, true);

    // 词汇
    $('#btnResetMatch').addEventListener('click', resetMatch);
    $('#btnShowMatch').addEventListener('click', showMatchAnswers);
    $('#btnResetWrite').addEventListener('click', () => { buildWriting(); toast('写作练习已重置'); });
    $('#btnShowAllWrite').addEventListener('click', () => {
      $$('#writeList .wAnswer').forEach(box => {
        const id = box.id.replace('ans-', '');
        const item = window.WRITING_ITEMS.find(x => x.id === id);
        box.innerHTML = '<b>参考答案：</b><br>' + item.answers.map((a, k) => (k + 1) + '. ' + esc(a)).join('<br>') +
          `<span class="tip"><i>提醒：</i>${esc(item.tip)}</span>`;
        box.classList.remove('hidden');
      });
      toast('已显示全部参考答案');
    });

    // 滚动 / 尺寸变化时重绘墨迹与批注位置
    let raf;
    const relayout = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => { renderAnnos(); renderInk(); drawLines(); });
    };
    $('#leftScroll').addEventListener('scroll', () => { drawLines(); }, { passive: true });
    window.addEventListener('resize', relayout);
    document.addEventListener('fullscreenchange', relayout);
  }

  /* ================= 初始化 ================= */
  function init() {
    buildPassage();
    paraNodes.forEach((_, i) => bindInkLayer(inkLayerOf(i + 1)));
    passageEl.style.setProperty('--fs', S.fontSize + 'px');
    buildNav();
    buildMatch();
    buildWriting();
    const m = window.PASSAGE.meta;
    $('#paperMeta').textContent = `${m.paper}｜${m.section}｜${m.questions}｜${m.source}`;
    $('#vocabCount').textContent = window.READING_WORDS.length + window.WRITING_ITEMS.length;
    selectQuestion('q28');
    bindUI();
    // 首帧后统一设置一次墨迹层交互状态（修复首次渲染 pointer-events 未生效）
    requestAnimationFrame(() => {
      renderInk();
      applyInkMode();
    });
    console.log('[workbench] ready', {
      paragraphs: paraNodes.length,
      readingWords: window.READING_WORDS.length,
      writingItems: window.WRITING_ITEMS.length,
      questions: window.QUESTIONS.length
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
